const express = require('express');

const app = express();

app.use('/',(req,res,next) => {
    console.log('This always run');
    next();
});

app.use('/list',(req,res,next) => {
    res.send('<h2>Welcome to the list page</h2>');
});

app.listen(4000);